package com.example.mcimporter

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.text.DateFormat
import java.util.Date

private const val MC_PACKAGE = "com.mojang.minecraftpe"
private val VALID = setOf("mcpack", "mcworld", "mcaddon", "mctemplate")

private val ENDER_PURPLE = Color(0xFFA855F7)
private const val TIKTOK_URL = "https://www.tiktok.com/@mr.enderman39?_r=1&_t=ZS-9Bi7OwaYFhU"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                App(prefs, dark) { dark = it; prefs.edit().putBoolean("dark", it).apply() }
            }
        }
    }
}

private fun libDir(c: Context) = File(c.filesDir, "library").apply { mkdirs() }

private fun kindOf(f: File) = when (f.extension.lowercase()) {
    "mcworld", "mctemplate" -> "Mundo"
    "mcpack" -> "Pack / Textura"
    "mcaddon" -> "Addon"
    else -> "Otro"
}

private fun sizeText(b: Long) =
    if (b > 1_048_576) "%.1f MB".format(b / 1_048_576.0) else "%d KB".format(b / 1024)

private fun saveToLibrary(c: Context, uri: Uri): Boolean {
    var name = "archivo"
    c.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) name = it.getString(i)
        }
    }
    if (name.substringAfterLast('.', "").lowercase() !in VALID) return false
    c.contentResolver.openInputStream(uri)?.use { input ->
        File(libDir(c), name).outputStream().use { input.copyTo(it) }
    }
    return true
}

private fun importToMinecraft(c: Context, f: File) {
    val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        c.startActivity(Intent(intent).setPackage(MC_PACKAGE))
    } catch (e: ActivityNotFoundException) {
        try {
            c.startActivity(Intent.createChooser(intent, "Abrir con"))
        } catch (e2: Exception) {
            Toast.makeText(c, "No se encontró Minecraft", Toast.LENGTH_LONG).show()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App(prefs: SharedPreferences, dark: Boolean, onDark: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    fun list() = libDir(ctx).listFiles()?.toList() ?: emptyList()
    var files by remember { mutableStateOf(list()) }
    var screen by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var sortBy by remember { mutableIntStateOf(prefs.getInt("sortBy", 2)) }
    var asc by remember { mutableStateOf(prefs.getBoolean("asc", false)) }
    val tabs = listOf("Todo", "Mundos", "Packs", "Addons")
    fun reload() { files = list() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        var ok = 0; var bad = 0
        uris.forEach { if (runCatching { saveToLibrary(ctx, it) }.getOrDefault(false)) ok++ else bad++ }
        reload()
        if (bad > 0) Toast.makeText(ctx, "$ok guardados, $bad no compatibles", Toast.LENGTH_SHORT).show()
    }

    val shown = files.filter {
        when (tab) {
            1 -> kindOf(it) == "Mundo"
            2 -> kindOf(it) == "Pack / Textura"
            3 -> kindOf(it) == "Addon"
            else -> true
        }
    }.let { l ->
        val s = when (sortBy) {
            0 -> l.sortedBy { it.name.lowercase() }
            1 -> l.sortedBy { it.length() }
            else -> l.sortedBy { it.lastModified() }
        }
        if (asc) s else s.reversed()
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (screen == 0) "MC Importer" else "Ajustes") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(screen == 0, { screen = 0 }, { Icon(Icons.Default.Folder, null) }, label = { Text("Biblioteca") })
                NavigationBarItem(screen == 1, { screen = 1 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Ajustes") })
            }
        },
        floatingActionButton = {
            if (screen == 0) ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                icon = { Icon(Icons.Default.FolderOpen, null) },
                text = { Text("Buscar archivos") }
            )
        }
    ) { pad ->
        if (screen == 1) {
            Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null)
                        Text(
                            if (dark) "Modo oscuro" else "Modo claro",
                            Modifier.weight(1f).padding(start = 12.dp),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Switch(dark, onDark)
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Creador", style = MaterialTheme.typography.labelLarge)
                        Text("mr.Enderman", color = ENDER_PURPLE, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium)
                        FilledTonalButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TIKTOK_URL)))
                        }) { Text("Abrir TikTok") }
                    }
                }
            }
        } else Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                tabs.forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("Nombre", "Tamaño", "Fecha").forEachIndexed { i, t ->
                    FilterChip(sortBy == i, { sortBy = i; prefs.edit().putInt("sortBy", i).apply() }, { Text(t) }, Modifier.padding(end = 8.dp))
                }
                IconButton(onClick = { asc = !asc; prefs.edit().putBoolean("asc", asc).apply() }) {
                    Icon(if (asc) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward, if (asc) "Ascendente" else "Descendente")
                }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Toca «Buscar archivos» para añadir .mcworld, .mcpack o .mcaddon desde tu teléfono.")
                }
            } else LazyColumn(contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.name }) { f ->
                    Card(Modifier.fillMaxWidth().clickable { importToMinecraft(ctx, f) }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.nameWithoutExtension, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${kindOf(f)}, ${sizeText(f.length())}, ${DateFormat.getDateInstance().format(Date(f.lastModified()))}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            FilledTonalButton(onClick = { importToMinecraft(ctx, f) }) { Text("Importar") }
                            IconButton(onClick = { f.delete(); reload() }) { Icon(Icons.Default.Delete, "Eliminar") }
                        }
                    }
                }
            }
        }
    }
}
