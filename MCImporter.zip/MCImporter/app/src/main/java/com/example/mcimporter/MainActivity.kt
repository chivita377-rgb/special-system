package com.example.mcimporter

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.text.DateFormat
import java.util.Date

private const val MC_PACKAGE = "com.mojang.minecraftpe"
private val VALID = setOf("mcpack", "mcworld", "mcaddon", "mctemplate")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

private fun libDir(c: Context) = File(c.filesDir, "library").apply { mkdirs() }

private fun kindOf(f: File) = when (f.extension.lowercase()) {
    "mcworld", "mctemplate" -> "Mundo"
    "mcpack" -> "Pack / Textura"
    "mcaddon" -> "Addon"
    else -> "Otro"
}

private fun sizeText(b: Long) =
    if (b > 1_048_576) "%.1f MB".format(b / 1_048_576.0) else "%d KB".format(b / 1024)

private fun saveToLibrary(c: Context, uri: Uri): Boolean {
    var name = "archivo"
    c.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) name = it.getString(i)
        }
    }
    if (name.substringAfterLast('.', "").lowercase() !in VALID) return false
    c.contentResolver.openInputStream(uri)?.use { input ->
        File(libDir(c), name).outputStream().use { input.copyTo(it) }
    }
    return true
}

private fun importToMinecraft(c: Context, f: File) {
    val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        c.startActivity(Intent(intent).setPackage(MC_PACKAGE))
    } catch (e: ActivityNotFoundException) {
        try {
            c.startActivity(Intent.createChooser(intent, "Abrir con"))
        } catch (e2: Exception) {
            Toast.makeText(c, "No se encontró Minecraft", Toast.LENGTH_LONG).show()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App() {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(libDir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Todo", "Mundos", "Packs", "Addons")
    fun reload() { items = libDir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        var ok = 0; var bad = 0
        uris.forEach { if (runCatching { saveToLibrary(ctx, it) }.getOrDefault(false)) ok++ else bad++ }
        reload()
        if (bad > 0) Toast.makeText(ctx, "$ok guardados, $bad no compatibles", Toast.LENGTH_SHORT).show()
    }

    val shown = items.filter {
        when (tab) {
            1 -> kindOf(it) == "Mundo"
            2 -> kindOf(it) == "Pack / Textura"
            3 -> kindOf(it) == "Addon"
            else -> true
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("MC Importer") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                icon = { Icon(Icons.Default.FolderOpen, null) },
                text = { Text("Buscar archivos") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                tabs.forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Toca «Buscar archivos» para añadir .mcworld, .mcpack o .mcaddon desde tu teléfono.")
                }
            } else LazyColumn(contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.name }) { f ->
                    Card(Modifier.fillMaxWidth().clickable { importToMinecraft(ctx, f) }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.nameWithoutExtension, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${kindOf(f)}, ${sizeText(f.length())}, ${DateFormat.getDateInstance().format(Date(f.lastModified()))}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            FilledTonalButton(onClick = { importToMinecraft(ctx, f) }) { Text("Importar") }
                            IconButton(onClick = { f.delete(); reload() }) { Icon(Icons.Default.Delete, "Eliminar") }
                        }
                    }
                }
            }
        }
    }
}
