import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.mcimporter"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.mcimporter"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Descarga las librerías que la app guarda dentro del teléfono (para usarla sin wi-fi).
val assetLibs = mapOf(
    "jszip.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js",
    "three.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
    "PixelifySans.ttf" to "https://github.com/google/fonts/raw/main/ofl/pixelifysans/PixelifySans%5Bwght%5D.ttf"
)
tasks.register("downloadLibs") {
    doLast {
        val dir = file("src/main/assets/lib")
        dir.mkdirs()
        assetLibs.forEach { (name, url) ->
            val f = File(dir, name)
            if (!f.exists() || f.length() == 0L) {
                try {
                    URI(url).toURL().openStream().use { input -> f.outputStream().use { input.copyTo(it) } }
                } catch (e: Exception) {
                    if (name.endsWith(".js")) throw GradleException("No se pudo descargar $name: ${e.message}")
                    logger.warn("No se pudo descargar $name (la app usará la letra normal): ${e.message}")
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("downloadLibs") }
